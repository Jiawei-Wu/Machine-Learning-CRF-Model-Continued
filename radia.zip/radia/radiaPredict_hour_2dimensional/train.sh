crf_learn -c 4.0 --maxiter=14 template data/train.data model
