crf_test -m model data/test.data > log_process/test_log.txt
