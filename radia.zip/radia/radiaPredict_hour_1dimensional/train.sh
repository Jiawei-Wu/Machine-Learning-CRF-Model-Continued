crf_learn --maxiter=25 -c 4.0 template data/train.data model
